from Models.bmxs import Bmx
import os

## TOOLSET ##
#lenval
def len_val(mensaje, pieza="la pieza"):
	val = True
	while val:
		x = input(mensaje+": ")
		if len(x) > 8:
			print(f"El nombre de {pieza} no puede contener mas de 8 caracteres")
			val = True
		if len(x) < 4:
			print(f"El nombre de {pieza} no puede contener menos de 4 caracteres")
			val = True
		if len(x) <= 8 and len(x) >= 4: val = False
def clear():
	return os.system("clear")
### Funciones ##

def agregar_bmx(marca, cuadro, manillar, horquilla, avance, dire):
	catalogo = []

	bmx = Bmx(id, marca, cuadro, manillar, horquilla, avance, dire)
	catalogo.append(bmx)

	for i in range(len(catalogo)):
		print(catalogo[i].get_cuadro())

marca = len_val("Ingrese marca")
cuadro = len_val("Ingrese marca")
manillar = len_val("Ingrese marca")
dire = len_val("Ingrese marca")
clear()
horquilla = len_val("Ingrese marca y modelo")
avance = len_val("Ingrese Marca del avance")

